#!/usr/bin/env python3
"""
main.py
Entry point for Neon Street Racer.

Run with:
    python3 main.py
"""

import asyncio
import sys
import os

# Ensure the project root is on sys.path so `src` imports resolve
# correctly regardless of the working directory the script is run from.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.game import Game  # noqa: E402


async def main():
    game = Game()
    await game.run()


try:
    asyncio.run(main())
except RuntimeError:
    asyncio.create_task(main())
